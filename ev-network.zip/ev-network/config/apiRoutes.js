const express  = require("express");
const router   = express.Router();

const chargers   = require("../controllers/chargers");

// router.route("/chargers")
//   .get(chargers.index)
//   .post(chargers.create);
// router.route("/chargers/:id")
//   .get(chargers.show)
//   .put(chargers.update)
//   .delete(chargers.delete);

module.exports = router;
