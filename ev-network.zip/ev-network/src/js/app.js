
const googleMap = googleMap || {};


googleMap.mapSetup = function(){
  let canvas = document.getElementById('map-canvas');
  let mapOptions = {
    zoom: 12,
    center: new google.maps.LatLng(51.515236,-0.072214),
    mapTypeId: google.maps.MapTypeId.ROADMAP

  };
  this.map = new google.maps.Map(canvas, mapOptions);
  this.getChargers();
};

googleMap.getChargers = function(){
  $.get("http://api.openchargemap.io/v2/poi/?output=json&countrycode=GB&maxresults=500").done(this.loopThroughChargers);

  // $.get("http://api.openchargemap.io/v2/poi/?output=json&countrycode=GB&maxresults=500").done(function(data){
  //   console.log(data.AddressInfo.Latitude, data.AddressInfo.Longitude);
  // });

};

googleMap.loopThroughChargers = function(data){
  for (var i = 0; i < data.length; i++) {

  var myLatLng = {lat: data[i].AddressInfo.Latitude, lng: data[i].AddressInfo.Longitude};


     let marker = new google.maps.Marker({
       position: myLatLng,
      //  animation: google.maps.Animation.DROP,
       map: this.map,

     });

     console.log(myLatLng);

  }
  // $.each(data[0].AddressInfo.latitude, data[0].AddressInfo.longitude, (index, charger) => {
  //   setTimeout(() => {
  //     googleMap.createMarkerForCharger(charger);
  //   }, index * 13);
  // });
};

// googleMap.createMarkerForCharger =
// function(charger) {
//   let latLng = new
//   google.maps.LatLng(charger.latitude, charger.longitude);
//
//   let marker = new google.maps.Marker({
//     position: latLng,
//     animation: google.maps.Animation.DROP,
//     map: this.map,
//     icon: iconBase
//   });
//   this.addInfoWindowForCharger(charger, marker);
//
// };
//
// googleMap.addInfoWindowForCharger =
// function(charger, marker) {
//   google.maps.event.addListener(marker, 'click', () => {
//     if (typeof this.infoWindow != "undefined")
//     this.infoWindow.close();
//
//     this.infoWindow = new
//     google.maps.InfoWindow({
//       content:  `<img src="${charger.image}"><p>${ charger.location }</p>`
//     });
//     this.map.setCenter(marker.getPosition());
//     this.map.panBy(0, -200);
//     this.infoWindow.open(this.map, marker);
//   });
// };



$(googleMap.mapSetup.bind(googleMap));
